import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/adapters/http.js';
import { Gestor } from '../src/application/gestor.js';
import { MemoryStore } from '../src/adapters/memory.js';

test('registro, login, CRUD y aislamiento entre cuentas', async () => {
  const app = createApp(new Gestor(new MemoryStore()));
  const server = app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  try {
    const base = 'http://127.0.0.1:' + server.address().port;
    async function call(method, path, data, token) {
      const response = await fetch(base + path, {
        method, headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
        body: data && JSON.stringify(data)
      });
      return [response.status, await response.json()];
    }
    const password = 'Clave12345';
    const alice = { email: 'a@example.com', nombre: 'Alice', password };
    const bob = { ...alice, email: 'b@example.com', nombre: 'Bob' };
    assert.equal((await call('POST', '/api/auth/registro', alice))[0], 201);
    assert.equal((await call('POST', '/api/auth/registro', alice))[0], 409);
    assert.equal((await call('POST', '/api/auth/registro', bob))[0], 201);
    const [, a] = await call('POST', '/api/auth/login', alice);
    const [, b] = await call('POST', '/api/auth/login', bob);
    const phone = { modelo: 'A55', marca: 'Samsung', almacenamiento: 128, precio: 1250000 };
    const [status, saved] = await call('POST', '/api/celulares', phone, a.token);
    assert.equal(status, 201);
    assert.equal((await call('GET', '/api/celulares'))[0], 401);
    assert.deepEqual((await call('GET', '/api/celulares', null, b.token))[1], []);
    assert.equal((await call('PUT', '/api/celulares/' + saved.id, phone, b.token))[0], 404);
    assert.equal((await call('PUT', '/api/celulares/' + saved.id, { ...phone, almacenamiento: 256 }, a.token))[1].almacenamiento, 256);
    assert.equal((await call('DELETE', '/api/celulares/' + saved.id, null, a.token))[0], 200);
    assert.deepEqual((await call('GET', '/api/celulares', null, a.token))[1], []);
    await call('POST', '/api/auth/salir', {}, a.token);
    assert.equal((await call('GET', '/api/celulares', null, a.token))[0], 401);
  } finally {
    server.close();
  }
});
