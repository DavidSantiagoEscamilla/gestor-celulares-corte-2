import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Gestor } from '../src/application/gestor.js';
import { MemoryStore } from '../src/adapters/memory.js';

test('sesiones, persistencia a través del puerto y aislamiento del inventario', async () => {
  const store = new MemoryStore();
  const gestor = new Gestor(store);
  const datos = { nombre: 'Ana', email: 'ana@example.com', password: 'PruebaSegura1' };
  await gestor.registro(datos);
  await assert.rejects(gestor.registro(datos), { status: 409 });
  await assert.rejects(gestor.login({ ...datos, password: 'incorrecta' }), { status: 401 });
  const sesion = await gestor.login(datos);
  const ana = await gestor.autenticar(sesion.token);
  const otro = await gestor.registro({ ...datos, email: 'otro@example.com' });
  const valores = { modelo: 'A55', marca: 'Samsung', almacenamiento: '128', precio: '1200000.50' };
  const equipo = await gestor.crear(ana, valores);
  assert.equal(equipo.precio, 1200000.50);
  assert.deepEqual(await new Gestor(store).listar(ana), [equipo]);
  assert.deepEqual(await gestor.listar(otro.id), []);
  await assert.rejects(gestor.editar(otro.id, equipo.id, valores), { status: 404 });
  await assert.rejects(gestor.borrar(otro.id, equipo.id), { status: 404 });
  assert.equal((await gestor.editar(ana, equipo.id, { ...valores, almacenamiento: 256 })).almacenamiento, 256);
  await gestor.borrar(ana, equipo.id);
  assert.deepEqual(await gestor.listar(ana), []);
  await gestor.salir(sesion.token);
  await assert.rejects(gestor.autenticar(sesion.token), { status: 401 });
});
