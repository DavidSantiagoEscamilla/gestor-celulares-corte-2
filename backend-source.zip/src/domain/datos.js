export class ErrorAplicacion extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function texto(valor, campo, max = 100) {
  if (typeof valor !== 'string' || !valor.trim() || valor.trim().length > max) {
    throw new ErrorAplicacion(400, campo + ' inválido');
  }
  return valor.trim();
}

export function correo(valor) {
  const email = texto(valor, 'Correo', 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new ErrorAplicacion(400, 'Correo inválido');
  return email;
}

export function celular(datos) {
  const modelo = texto(datos.modelo, 'Modelo');
  const marca = texto(datos.marca, 'Marca');
  const almacenamiento = Number(texto(String(datos.almacenamiento ?? ''), 'Almacenamiento', 10));
  const precio = Number(texto(String(datos.precio ?? ''), 'Precio', 16));
  if (!Number.isInteger(almacenamiento) || almacenamiento < 1 || almacenamiento > 1000000) {
    throw new ErrorAplicacion(400, 'Ingresa el almacenamiento en GB como un entero positivo');
  }
  if (!Number.isFinite(precio) || precio < 0 || precio > 999999999999) {
    throw new ErrorAplicacion(400, 'Ingresa un precio válido en COP');
  }
  return { modelo, marca, almacenamiento, precio: Math.round(precio * 100) / 100 };
}
