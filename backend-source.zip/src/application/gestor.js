import { randomUUID, randomBytes, createHash, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { celular, correo, texto, ErrorAplicacion } from '../domain/datos.js';

const scrypt = promisify(scryptCallback);
const hashToken = token => createHash('sha256').update(token).digest('hex');

export class Gestor {
  // Puerto de salida: el almacén implementa usuarios, sesiones e inventario.
  constructor(store) {
    this.store = store;
  }

  async registro(datos) {
    const email = correo(datos.email);
    const nombre = texto(datos.nombre, 'Nombre');
    const password = datos.password;
    if (typeof password !== 'string' || password.trim().length < 8 || password.length > 128) {
      throw new ErrorAplicacion(400, 'La contraseña debe tener entre 8 y 128 caracteres');
    }
    const salt = randomBytes(16).toString('hex');
    const hash = (await scrypt(password, salt, 64)).toString('hex');
    const usuario = { id: randomUUID(), email, nombre };
    if (!await this.store.crearUsuario({ ...usuario, salt, hash })) {
      throw new ErrorAplicacion(409, 'Ya existe una cuenta con ese correo');
    }
    return usuario;
  }

  async login(datos) {
    const email = correo(datos.email);
    const password = datos.password;
    if (typeof password !== 'string' || password.length > 128) throw new ErrorAplicacion(401, 'Credenciales inválidas');
    const usuario = await this.store.buscarUsuario(email);
    const hash = await scrypt(password, usuario?.salt ?? 'salt-de-verificacion', 64);
    if (!usuario || !timingSafeEqual(hash, Buffer.from(usuario.hash, 'hex'))) {
      throw new ErrorAplicacion(401, 'Correo o contraseña incorrectos');
    }
    const token = randomBytes(32).toString('hex');
    await this.store.crearSesion(hashToken(token), usuario.id, new Date(Date.now() + 24 * 3600 * 1000));
    return { token, email, nombre: usuario.nombre };
  }

  async autenticar(token) {
    const id = /^[a-f0-9]{64}$/.test(token) && await this.store.buscarSesion(hashToken(token));
    if (!id) throw new ErrorAplicacion(401, 'Inicia sesión para continuar');
    return id;
  }

  salir(token) { return this.store.borrarSesion(hashToken(token)); }
  listar(usuario) { return this.store.listar(usuario); }
  crear(usuario, datos) { return this.store.crear(usuario, { id: randomUUID(), ...celular(datos) }); }

  async editar(usuario, id, datos) {
    const resultado = await this.store.editar(usuario, id, celular(datos));
    if (!resultado) throw new ErrorAplicacion(404, 'Celular no encontrado');
    return resultado;
  }

  async borrar(usuario, id) {
    if (!await this.store.borrar(usuario, id)) throw new ErrorAplicacion(404, 'Celular no encontrado');
    return { eliminado: true };
  }
}
