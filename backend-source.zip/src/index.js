import pg from 'pg';
import { Gestor } from './application/gestor.js';
import { createApp } from './adapters/http.js';
import { PostgresStore } from './adapters/postgres.js';

if (!process.env.DATABASE_URL) throw new Error('Configura DATABASE_URL antes de iniciar');
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 5 });
const store = new PostgresStore(pool);
await store.iniciar();
createApp(new Gestor(store), () => pool.query('SELECT 1'))
  .listen(Number(process.env.PORT ?? 3000), '0.0.0.0');
