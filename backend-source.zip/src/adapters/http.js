import express from 'express';
import { rateLimit } from 'express-rate-limit';
import { ErrorAplicacion } from '../domain/datos.js';

export function createApp(gestor, comprobarDb = async () => {}) {
  const app = express();
  if (process.env.RENDER === 'true') app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use(express.json({ limit: '16kb' }));
  app.use(express.urlencoded({ extended: false, limit: '16kb' }));
  const limite = rateLimit({
    windowMs: 60_000, limit: 12,
    message: { mensaje: 'Demasiados intentos. Espera un minuto.' }
  });
  app.get('/health', async (_, res) => {
    await comprobarDb();
    res.json({ estado: 'ok' });
  });
  app.post('/api/auth/registro', limite, async (req, res) => {
    res.status(201).json(await gestor.registro(req.body ?? {}));
  });
  app.post('/api/auth/login', limite, async (req, res) => {
    const sesion = await gestor.login(req.body ?? {});
    res.set('Cache-Control', 'no-store');
    res.json(req.query.formato === 'kodular' ? [sesion.token, sesion.email, sesion.nombre] : sesion);
  });

  const privadas = express.Router();
  privadas.use(async (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    req.token = /^Bearer (.+)$/i.exec(req.get('Authorization') ?? '')?.[1] ?? '';
    req.usuario = await gestor.autenticar(req.token);
    next();
  });
  privadas.param('id', (req, res, next, id) => {
    if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(id)) {
      throw new ErrorAplicacion(404, 'Celular no encontrado');
    }
    next();
  });
  privadas.post('/auth/salir', async (req, res) => {
    await gestor.salir(req.token);
    res.json({ cerrado: true });
  });
  privadas.get('/celulares', async (req, res) => {
    const celulares = await gestor.listar(req.usuario);
    res.json(req.query.formato === 'kodular'
      ? celulares.map(({ id, modelo, marca, almacenamiento, precio }) => [id, modelo, marca, almacenamiento, precio])
      : celulares);
  });
  privadas.post('/celulares', async (req, res) => res.status(201).json(await gestor.crear(req.usuario, req.body ?? {})));
  privadas.put('/celulares/:id', async (req, res) => res.json(await gestor.editar(req.usuario, req.params.id, req.body ?? {})));
  privadas.delete('/celulares/:id', async (req, res) => res.json(await gestor.borrar(req.usuario, req.params.id)));
  app.use('/api', privadas);
  app.use((_, res) => res.status(404).json({ mensaje: 'Ruta no encontrada' }));
  app.use((error, req, res, next) => {
    const status = error.status >= 400 && error.status < 500 ? error.status : 500;
    if (status === 500) console.error(error);
    res.status(status).json({ mensaje: error instanceof ErrorAplicacion ? error.message : status === 500 ? 'Error del servidor' : 'Petición inválida' });
  });
  return app;
}
