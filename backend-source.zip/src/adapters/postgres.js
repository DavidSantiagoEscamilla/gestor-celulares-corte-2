const campos = 'id, modelo, marca, almacenamiento, precio::float8 AS precio';

export class PostgresStore {
  constructor(pool) { this.pool = pool; }

  async iniciar() {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id uuid PRIMARY KEY, email text UNIQUE NOT NULL, nombre text NOT NULL,
        salt text NOT NULL, hash text NOT NULL
      );
      CREATE TABLE IF NOT EXISTS sesiones (
        hash text PRIMARY KEY, usuario uuid NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        vence timestamptz NOT NULL
      );
      CREATE TABLE IF NOT EXISTS celulares (
        id uuid PRIMARY KEY, usuario uuid NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        modelo text NOT NULL, marca text NOT NULL, almacenamiento int NOT NULL CHECK (almacenamiento > 0),
        precio numeric(14,2) NOT NULL CHECK (precio >= 0)
      );
      CREATE INDEX IF NOT EXISTS celulares_usuario ON celulares(usuario);
      CREATE INDEX IF NOT EXISTS sesiones_vence ON sesiones(vence);
    `);
  }

  async crearUsuario({ id, email, nombre, salt, hash }) {
    const result = await this.pool.query(
      'INSERT INTO usuarios VALUES ($1,$2,$3,$4,$5) ON CONFLICT (email) DO NOTHING',
      [id, email, nombre, salt, hash]
    );
    return result.rowCount === 1;
  }

  async buscarUsuario(email) {
    return (await this.pool.query('SELECT * FROM usuarios WHERE email=$1', [email])).rows[0];
  }

  async crearSesion(hash, usuario, vence) {
    await this.pool.query('DELETE FROM sesiones WHERE vence <= now()');
    await this.pool.query('INSERT INTO sesiones VALUES ($1,$2,$3)', [hash, usuario, vence]);
  }

  async buscarSesion(hash) {
    return (await this.pool.query('SELECT usuario FROM sesiones WHERE hash=$1 AND vence > now()', [hash])).rows[0]?.usuario;
  }

  async borrarSesion(hash) {
    await this.pool.query('DELETE FROM sesiones WHERE hash=$1', [hash]);
  }

  async listar(usuario) {
    return (await this.pool.query('SELECT ' + campos + ' FROM celulares WHERE usuario=$1 ORDER BY modelo, id', [usuario])).rows;
  }

  async crear(usuario, { id, modelo, marca, almacenamiento, precio }) {
    return (await this.pool.query('INSERT INTO celulares VALUES ($1,$2,$3,$4,$5,$6) RETURNING ' + campos,
      [id, usuario, modelo, marca, almacenamiento, precio])).rows[0];
  }

  async editar(usuario, id, { modelo, marca, almacenamiento, precio }) {
    return (await this.pool.query('UPDATE celulares SET modelo=$3, marca=$4, almacenamiento=$5, precio=$6 WHERE usuario=$1 AND id=$2 RETURNING ' + campos,
      [usuario, id, modelo, marca, almacenamiento, precio])).rows[0];
  }

  async borrar(usuario, id) {
    return (await this.pool.query('DELETE FROM celulares WHERE usuario=$1 AND id=$2', [usuario, id])).rowCount === 1;
  }
}
