export class MemoryStore {
  usuarios = new Map();
  sesiones = new Map();
  celulares = new Map();

  crearUsuario(usuario) {
    if (this.usuarios.has(usuario.email)) return false;
    this.usuarios.set(usuario.email, usuario);
    return true;
  }

  buscarUsuario(email) { return this.usuarios.get(email); }
  crearSesion(hash, id, vence) { this.sesiones.set(hash, { id, vence }); }
  borrarSesion(hash) { this.sesiones.delete(hash); }
  buscarSesion(hash) {
    const sesion = this.sesiones.get(hash);
    return sesion?.vence > Date.now() ? sesion.id : null;
  }

  listar(usuario) {
    return [...(this.celulares.get(usuario)?.values() ?? [])];
  }

  crear(usuario, datos) {
    if (!this.celulares.has(usuario)) this.celulares.set(usuario, new Map());
    this.celulares.get(usuario).set(datos.id, datos);
    return datos;
  }

  editar(usuario, id, datos) {
    if (!this.celulares.get(usuario)?.has(id)) return null;
    return this.crear(usuario, { id, ...datos });
  }

  borrar(usuario, id) { return this.celulares.get(usuario)?.delete(id); }
}
